📁 assets/images/
در این پوشه باید تصاویر مربوط به صفحات کتاب قرار بگیرند.
مثلاً:
- page_01.png
- page_02.jpg
- cover.jpg
