📁 assets/audio/
در این پوشه باید صداهای پس‌زمینه، افکت‌ها یا صدای نمونه قرار بگیرند.
مثلاً:
- rain.mp3
- forest.wav
- sample_voice.mp3
